﻿using UnityEngine;
using System.Collections;

public class BaseGame : MonoBehaviour {

	public GameObject[] rowContainer = new GameObject[0];
	//public int currentBlocks = 4;

	void Start()
	{
		System.Array.Resize(ref rowContainer, Camera.main.GetComponent<GlobalVariables>().TOTAL_ROWS);
		for (int i = 0; i < rowContainer.Length; i++)
		{
			rowContainer[i] = (GameObject)Instantiate(Resources.Load("BlockRow"));
			rowContainer[i].name = "BlockRow" + i.ToString();
			rowContainer[i].transform.parent = transform;
			rowContainer[i].GetComponent<BlockRow>().assignAssetToBlock(i);
		}
	}

	void Update () {}
}
