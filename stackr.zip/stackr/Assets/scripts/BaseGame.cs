﻿using UnityEngine;
using System.Collections;

public class BaseGame : MonoBehaviour {

	public GameObject[] rowContainer = new GameObject[0];
	public GameObject easyPrize;
	public GameObject bestPrize;
	public int currentBlocks = 4;
	public int currentRow = 0;

	void Start()
	{
		//Set up BlockRows
		System.Array.Resize(ref rowContainer, Camera.main.GetComponent<GlobalVariables>().TOTAL_ROWS);
		for (int i = 0; i < rowContainer.Length; i++)
		{
			rowContainer[i] = (GameObject)Instantiate(Resources.Load("BlockRow"));
			rowContainer[i].name = "BlockRow" + i.ToString();
			rowContainer[i].transform.parent = transform;
			rowContainer[i].GetComponent<BlockRow>().AssignAssetToBlock(i);
		}
		NextRow();
		InvokeRepeating("UpdateRow", 0, 0.1F);


		//Set up Prize lines
		easyPrize = (GameObject)Instantiate(Resources.Load("EasyPrize"));
		easyPrize.name = "EasyPrize";
		easyPrize.transform.parent = transform;
		easyPrize.GetComponent<PrizeRow>().ReceiveData(Camera.main.GetComponent<GlobalVariables>().EASY_PRIZE_ROW);

		bestPrize = (GameObject)Instantiate(Resources.Load("BestPrize"));
		bestPrize.name = "BestPrize";
		bestPrize.transform.parent = transform;
		bestPrize.GetComponent<PrizeRow>().ReceiveData(Camera.main.GetComponent<GlobalVariables>().BEST_PRIZE_ROW);
	}

	void Update ()
	{
		if (Camera.main.GetComponent<GlobalVariables>().INPUT_NORMAL_CLICK)
		{
			NextRow();
		}
	}

	void UpdateRow()
	{
		rowContainer[currentRow-1].GetComponent<BlockRow>().UpdateRow();
	}

	void NextRow()
	{
		for (int i = 0; i < currentBlocks; i++)
		{
			rowContainer[currentRow].GetComponent<BlockRow>().SetActiveInRow(i,true);
		}
		currentRow++;
	}
}