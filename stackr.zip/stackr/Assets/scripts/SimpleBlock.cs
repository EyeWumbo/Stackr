﻿using UnityEngine;
using System.Collections;

public class SimpleBlock : MonoBehaviour {

	bool isActive = true;
	bool isBackground = true;

	// Use this for initialization
	void Start () {
		//(screen width)*(block width ratio)/(sprite size)
		//Screen.width * 0.14285714285f / 
		transform.localScale = new Vector3(Screen.width * 0.14285714285f / Camera.main.GetComponent<GlobalVariables>().SPRITE_BLOCK_WIDTH,
		                                   Screen.height * 0.08333333333f / Camera.main.GetComponent<GlobalVariables>().SPRITE_BLOCK_HEIGHT,
		                                   1);
	}

	public void receiveAssetForBlock(int x_pos, int y_pos){
		int margin =  (int)(Camera.main.pixelWidth * 0.1 / 8), size = (int)(Camera.main.pixelWidth * 0.9 / 7 / Screen.height);
		transform.position = new Vector2(
			(x_pos * margin + (x_pos - 1) * size),
			y_pos * margin + (y_pos - 1) * size
		);
	}

	// Update is called once per frame
	void Update () {
	
	}
}
