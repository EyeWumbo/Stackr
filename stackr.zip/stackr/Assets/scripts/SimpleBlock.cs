﻿using UnityEngine;
using System.Collections;

public class SimpleBlock : MonoBehaviour {

	bool isActive = true;
	bool isBackground = true;
	int x;
	int y;

	public void receiveAssetForBlock(int x_pos, int y_pos){
		x = x_pos;
		y = y_pos;
	}
	
	void Update () {
		transform.localScale = new Vector3(	Camera.main.pixelWidth / Camera.main.GetComponent<GlobalVariables>().SPRITE_BLOCK_WIDTH * Camera.main.orthographicSize,
		                                   Camera.main.pixelHeight / Camera.main.GetComponent<GlobalVariables>().SPRITE_BLOCK_HEIGHT * Camera.main.orthographicSize,
											1);

		float displacementX = (Camera.main.pixelWidth / Camera.main.GetComponent<GlobalVariables>().TOTAL_COLUMNS / 100);
		float displacementY = (Camera.main.pixelHeight / Camera.main.GetComponent<GlobalVariables>().TOTAL_ROWS / 100);
		transform.position = new Vector2(x * displacementX - Camera.main.pixelWidth / 100,
		                                 y * displacementY - Camera.main.pixelHeight / 100);

	}
}
