﻿using UnityEngine;
using System.Collections;

public class BlockRow : MonoBehaviour {
	
	public GameObject[] rowBlocks = new GameObject[0];
	public bool isActive = true;

	//Treat this as the start function for BlockRow because it requires y_pos
	public void assignAssetToBlock(int y_pos){
		System.Array.Resize(ref rowBlocks, Camera.main.GetComponent<GlobalVariables>().TOTAL_COLUMNS);
		for (int i = 0; i < rowBlocks.Length; i++)
		{
			rowBlocks[i] = (GameObject)Instantiate(Resources.Load("SimpleBlock"));
			rowBlocks[i].name = "SimpleBlock" + i.ToString();
			rowBlocks[i].transform.parent = transform;
			rowBlocks[i].GetComponent<SimpleBlock>().receiveAssetForBlock(i, y_pos);
		}
	}
	
	private bool getBelow(BlockRow row){
		return false;
	}

	void Update () {
	
	}
	
}
