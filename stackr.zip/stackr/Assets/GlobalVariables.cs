﻿using UnityEngine;
using System.Collections;

public class GlobalVariables : MonoBehaviour {

	public readonly int SPRITE_BLOCK_WIDTH = 373;
	public readonly int SPRITE_BLOCK_HEIGHT = 344;

}
