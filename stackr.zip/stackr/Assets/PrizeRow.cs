﻿using UnityEngine;
using System.Collections;

public class PrizeRow : MonoBehaviour {

	int y;
	bool showing = true;
	bool hiding = false;

	void Start()
	{
		print(renderer.material.color.a);
	}

	void Update()
	{
		rescale();

		if (Input.GetKeyDown(KeyCode.Q))
		{
			showing = true;
			renderer.material.color += new Color(0,0,0,0.1f);
		}
		if (Input.GetKeyDown(KeyCode.W))
		{
			hiding = true;
		}
		if (showing)
		{
			print ("showing reached");
			if (renderer.material.color.a <1)
			{
				print ("increasing alpha" + renderer.material.color.a.ToString());
				renderer.material.color += new Color(0,0,0,0.1f);
			}
			else
			{
				showing = false;
			}
		}
		else if (hiding)
		{
			print ("hiding reached");
			if (renderer.material.color.a > 0)
			{
				print ("decreasing alpha" + renderer.material.color.a.ToString());
				renderer.material.color -= new Color(0,0,0,0.1f);
			}
			else
			{
				hiding = false;
			}
		}
	}

	public void ReceiveData(int row)
	{
		y = row;
	}

	public void CustomShow()
	{
	}

	public void CustomHide()
	{
	}

	//Manages the rescaling based on different screen sizes
	private void rescale()
	{
		//Get resources
		SpriteRenderer sr = GetComponent<SpriteRenderer>();
		if (sr == null) return;
		transform.localScale = new Vector3(1,1,1);
		
		//Find dimensions of sprite when rendered
		float spriteWidth = sr.sprite.bounds.size.x;
		float spriteHeight = sr.sprite.bounds.size.y;
		
		//Find dimensions of camera view when rendered
		float workingHeight = Camera.main.orthographicSize * 2f - Camera.main.GetComponent<GlobalVariables>().PAD_Y;
		float workingWidth = workingHeight / Screen.height * Screen.width - Camera.main.GetComponent<GlobalVariables>().PAD_X;
		
		float scale = 0;
		float customScaleX = 0;
		float customScaleY = 0;
		if (workingWidth/workingHeight > (float)Camera.main.GetComponent<GlobalVariables>().TOTAL_COLUMNS/Camera.main.GetComponent<GlobalVariables>().TOTAL_ROWS) //Too wide, center by X
		{
			//Resize sprite
			scale = workingHeight / spriteHeight / Camera.main.GetComponent<GlobalVariables>().TOTAL_ROWS;
			customScaleX = scale * Camera.main.GetComponent<GlobalVariables>().TOTAL_COLUMNS;
			customScaleY = scale;
			transform.localScale = new Vector2(customScaleX, customScaleY);
			
			//Reposition sprite
			transform.position =	new Vector2(0, y * workingHeight / Camera.main.GetComponent<GlobalVariables>().TOTAL_ROWS) - 
									new Vector2(workingWidth / 2, workingHeight / 2) +
									new Vector2((workingWidth - Camera.main.GetComponent<GlobalVariables>().TOTAL_COLUMNS * scale * spriteWidth)/2, 0);
			transform.position = new Vector3(transform.position.x, transform.position.y, -1);
		}
		else //Too tall, center by Y
		{
			//Resize sprite
			scale = workingWidth / spriteWidth / Camera.main.GetComponent<GlobalVariables>().TOTAL_COLUMNS;
			customScaleX = scale * Camera.main.GetComponent<GlobalVariables>().TOTAL_COLUMNS;
			customScaleY = scale;
			transform.localScale = new Vector2(customScaleX, customScaleY);
			
			//Reposition sprite
			transform.position =	new Vector2(0, y * workingWidth / Camera.main.GetComponent<GlobalVariables>().TOTAL_COLUMNS) -
									new Vector2(workingWidth / 2, workingHeight / 2) +
									new Vector2(0, (workingHeight - Camera.main.GetComponent<GlobalVariables>().TOTAL_ROWS * scale * spriteHeight)/2);
			transform.position = new Vector3(transform.position.x, transform.position.y, -1);
		}

		//Rescale with gui fade in/out

	}
}
